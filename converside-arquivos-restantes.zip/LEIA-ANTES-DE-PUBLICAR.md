# Converside — pacote para publicação web

Este pacote reúne o protótipo atual com manifesto PWA, ícones, instalação opcional e cache básico para abrir a interface offline após uma primeira visita. **É uma preparação técnica do site, não uma garantia de que todas as funções estão prontas nem uma publicação online.**

## Publicar como site no Chrome
1. Extraia o ZIP e envie todos os arquivos e pastas desta pasta para uma hospedagem estática com HTTPS.
2. Verifique que `https://SEU-DOMINIO/`, `/manifest.webmanifest`, `/sw.js`, `/icon.svg` e `/icons/icon-192.png` abrem corretamente.
3. No Android/Chrome, teste cada menu, criar/editar/excluir conteúdo, backup/restauração, teclado, orientação da tela e conexões lentas. O botão “Instalar app” pode aparecer quando o navegador considerar o site instalável; alternativamente, use o menu do Chrome > “Instalar app”/“Adicionar à tela inicial”.
4. O cache offline só guarda o shell da interface. Conteúdo externo, mídia e recursos online continuam dependendo de conexão.

## Antes de abrir ao público
- Criar backend seguro para cadastro/login, perfis, mensagens em tempo real, comunidades, sincronização e armazenamento de mídia.
- Implementar exclusão de conta e dados, política de privacidade real, termos, contato de suporte e regras da comunidade.
- Implementar denúncia, bloqueio, moderação e resposta a abuso; são essenciais numa rede social.
- Validar e limitar uploads e entradas; proteger contra spam, abuso e ataques; backups e monitoramento.
- Não tratar `localStorage`, moedas locais ou permissões visuais como autenticação, compra ou segurança real.
- Usar somente mídia própria ou licenciada. A interface não dá direitos sobre músicas, vídeos ou anime de terceiros.
- Testar funcionalmente em aparelhos reais, acessibilidade, compatibilidade e segurança. Corrigir qualquer botão/menu quebrado antes de anunciar.

## Depois: Google Play
1. Estabilizar e publicar primeiro a versão web em HTTPS.
2. Para Android, escolher uma Trusted Web Activity/PWA empacotada ou criar app nativo. O pacote atual não é um APK nem AAB.
3. Gerar um Android App Bundle (`.aab`) assinado, configurar a Play Console e fornecer ícones, capturas, classificação etária, formulário de segurança de dados, política de privacidade e testes exigidos.
4. Conferir os requisitos atuais da Play Console antes do envio. A aprovação depende da revisão do Google e não é garantida.

## Limitações atuais conhecidas
Os dados são majoritariamente locais no navegador; não existe backend de contas, sincronização entre dispositivos, mensagens reais entre usuários, pagamentos reais ou IA conectada por API. A instalação PWA não é publicação na Play Store.
